<?php
//variabel koneksi
$konek = mysqli_connect("localhost","root","","sppsekolah");

if(!$konek){
	echo "Koneksi Database Gagal...!!!";
}
?>