<?php include "header.php"; ?>

<h3>Selamat Datang di Dashboard Aplikasi Pembayaran SPP</h3>
<p>Silahkan dikelola dengan baik ya....</p>

<?php include "footer.php"; ?>
